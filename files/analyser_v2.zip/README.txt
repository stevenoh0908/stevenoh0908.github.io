# README.txt
# 코드 사용시 주의사항

# UPDATE_LOG (17 Aug 2022)
- 시간격을 코드에서 임의로 수정할 수 있도록 변경하였습니다.
- analyser 모듈에 추가된 setTimestamps 메서드를 example.py의 예제 코드에서 사용법을 확인하시기 바랍니다.
- 주의! 반드시 csv 파일은 utf-8 인코딩으로 저장하여야 합니다. 일반적으로 excel에서 곧바로 utf-8 형태로 csv로 저장하는 경우, 일반적으로 인코딩은 utf-8이 아닌 utf-8 with BOM 인코딩으로 저장됩니다. 해당 파일은 python 코드로 열 수 없으므로 주의하시기 바랍니다.

1. 이 코드는 python 3.10 64-bit 환경에서 test 되었습니다. 그러나 python 3.7 이상의 버전에서는 모두 이상 없이 동작할 것으로 예상됩니다.
2. 코드 사용 이전에 이 폴더에 있는 install.bat 파일을 더블클릭하여 실행하십시오.
3. bat 파일 실행 이후 화면에 'Installed Successfully'가 출력되면 창을 닫고, 용도에 맞게 코드를 작성한 후 (example.py와 analyser.py 참고) 코드를 더블 클릭하여 실행하십시오.
   (아마 example.py를 수정한 뒤 더블클릭하여 실행하는 경우가 많을 것으로 보입니다.)

# .csv 파일 주의사항
1. 모든 csv 파일은 time, left_eye, right_eye, average로 시작하는 헤더를 가지고 있어야 합니다. (exp2-1.csv 등 참조)
2. 모든 csv 파일은 utf-8 encoding으로 저장되어야 합니다. excel에서 csv로 저장하는 경우, 기본 인코딩은 utf-8이 아니므로, 엑셀에서 저장한 csv 파일을 메모장으로 열어 다른 이름으로 저장하기를 눌러 utf-8 인코딩으로 저장하여야만 해당 csv 파일이 정상적으로 이용됩니다.
