# example.py
# Created on 13 Aug 2022, by Stephen Oh (stevenoh0908@gmail.com)
# Modified on 17 Aug 2022, by Stephen Oh (stevenoh0908@gmail.com)

# This Code shows how to use analyser.py properly.
# If you have any question with my codes, please let me know via my email.

# NOTE: if you want to get analysis of the data such as correlation matrix or coef or intercept of linear regression, make sure to execute your code in command line or python shell.

# HOW TO USE ANALYSER.PY PROPERLY:
# 0. import Analyser class from analyser.py to your code.
from analyser import Analyser
# 1. create instance.
analyser = Analyser()
# 2. add files that you want to get an analysis or plots, with keys.
analyser.addFile('rest1', 'rest1.csv')
analyser.addFile('eb1', 'eb1.csv')
#analyser.addFile('tab data', 'tab data.csv')
#analyser.addFile('phone data', 'phone data.csv')
# 3. plot as you want. if you want to save your figures, make sure to set 'save' variable when you're using a method.
# ALSO: make sure that you set the title, xlabel, ylabel of your plot. otherwise, it will automatically to set defaults.
# NOTE: plotBoxNRegression method requires ONE key to plot, others will require MULTIPLE keys as LIST to plot.
# NOTE: if you think that the figure is too small, use setFigsize method.
# NOTE: if you think that the figure has too low resolution, use setDPI method. (to see what is DPI, see here: https://stackoverflow.com/questions/47633546/relationship-between-dpi-and-figure-size)
# [NEW] NOTE: if you changed your timestamps from [0, 5, 10, ..., 60] to another, set it properly via setTimestamps method.
analyser.setFigsize(6, 4) # 6 inch width, 4 inch height.
analyser.setDPI(1200) # set dpi to 1200 (Very High Resolution)
analyser.setTimestamps([2, 4, 6, 8, 10]) # make sure to use integer-contained-list as input.
analyser.plotBoxNRegression('rest1', title='Eye Surf Temp. (Both Avg. / Avg Dist / Rest.)', xlabel='Time (m)', ylabel='Temperature (C)', save='rest1.jpeg')
analyser.setTimestamps([0, 10, 20, 30, 40, 50, 60]) # make sure to set timestamps everytime you change your timestamps in csv file.
analyser.plotBoxNRegression('eb1', title='Test', xlabel='t', ylabel='T', save='eb1.jpeg')
#analyser.plotBoxNRegression('exp2-1', title='Eye Surf Temp. (Both Avg. / Avg Dist.)', xlabel='Time (m)', ylabel='Temperature (C)', save='2-1.jpeg')
#analyser.plotMultipleScatterNRegression(['exp2-1', 'tab data', 'phone data'], anomaly=True, labels=['Computer.', 'Tablet.', 'Smart Phone.'], title='$\delta$ Eye Surf Temp. (Both Avg.)', xlabel='Time (m)', ylabel='Temperature (C)', save='type1.jpeg')
#analyser.plotMultipleMeanRegression(['exp2-1', 'tab data', 'phone data'], anomaly=True, labels=['Computer.', 'Tablet.', 'Smart Phone.'], title='$\delta$ Eye Surf Temp. (Both Avg.)', xlabel='Time (m)', ylabel='Temperature (C)', save='type2.jpeg')
# 4. ALL DONE!
