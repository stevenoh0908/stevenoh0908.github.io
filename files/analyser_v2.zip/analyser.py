# analyser.py
# Created on 13 Aug 2022, by Stephen Oh (stevenoh0908@gmail.com)
# A simple & directive plotting with analysis program for sister's research.
# If you have any question or bug report with these following codes, please let me know at once via my email.

# >> A Simple Direction for usage of this code (13 Aug 2022)
# 1. import class Analyser this code to your code (ref to example code contained.)
# 2. with referring to comments on each method, use appropriately.

# >> Note for plotting methods (13 Aug 2022)
# - In all below method of class Analyser, title is variable for setting plot's title, xlabel is variable for setting label of x-axis, ylabel is variable for setting label of y-axis.

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

class Analyser:
    def __init__(self):
        self.filepaths = {}
        self.dataframes = {}
        self.figwidth, self.figheight = 5, 4
        self.timestamps = list(range(0, 61, 5))
        self.dpi = 600
        pass
    # add filename to self.filepaths and init dataframe from given filename.
    def addFile(self, key, filename):
        self.filepaths[key] = filename
        with open(filename, 'r') as file:
            self.dataframes[key] = pd.read_csv(file, encoding='utf-8')
            pass
        return
    # remove file from self.filepaths ans self.dataframes
    def removeFile(self, key):
        del self.filepaths[key]
        del self.dataframes[key]
        return
    # set figure size (with inch)
    def setFigsize(self, width, height):
        self.figwidth = width
        self.figheight = height
        return
    # set dpi
    def setDPI(self, dpi):
        self.dpi = dpi
        return
    # set timestamps
    def setTimestamps(self, times):
        self.times = times
        return
    # get timestamps
    def getTimestamps(self):
        return self.times
    # show all filepaths added
    def getFilepaths(self):
        return self.filepaths
    # get all dataframes added with given filenames
    def getDataframes(self):
        return self.dataframes
    # plot Boxplot & Linear Regression with data stored with given key.
    # if save directory is given, export plot as image with given dir. directory must include full path, with file extension.
    # category (optional): if given, plot data with given special category. default option is average, which indicates data of both eye's mean.
    def plotBoxNRegression(self, key, save=None, title='title', xlabel='xlabel', ylabel='ylabel', category='average'):
        plt.clf()
        plt.figure(figsize=(self.figwidth, self.figheight))
        df = self.dataframes[key]
        series_by_time = []
        for time in self.times:
            series_by_time.append(df[df['time'] == time].reset_index(drop=True)[category])
            pass
        plt.boxplot(series_by_time, showmeans=True)
        plt.xticks([i for i in range(1, len(self.times)+1)], [str(i) for i in self.times])
        plt.title(title)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        # linear regression
        meandt = df.groupby(by='time').mean()[category].reset_index()
        reg = LinearRegression().fit(meandt['time'].values.reshape(-1, 1), meandt[category])
        plt.plot(meandt['time'] / (self.times[1] - self.times[0]) + (1 if self.times[0] == 0 else 0), meandt['time'] * reg.coef_ + reg.intercept_, color='green')
        print(f'Analysis of {title}')
        print(f'coef: {reg.coef_}, intercept: {reg.intercept_}')
        print(f'corr\n{df.corr(method="pearson")}')
        plt.tight_layout()
        if save:
            plt.savefig(save, dpi=self.dpi)
            pass
        else:
            plt.show()
            pass
        return
    # plot Multiple Scatter & Linear Regression with data stored with given keys.
    # if save directory is given, export plot as image with given dir. directory must include full path, with file extension.
    # category (optional): if given, plot data with given special category. default option is average, which indicates data of both eye's mean.
    # anomaly (optional): if given, plot anomaly of ys of data.
    def plotMultipleScatterNRegression(self, keys, labels=[], save=None, title='title', xlabel='xlabel', ylabel='ylabel', category='average', anomaly=False):
        plt.clf()
        plt.figure(figsize=(self.figwidth, self.figheight))
        if not labels: labels = keys
        dfs = [self.dataframes[key] for key in keys]
        for dfi, label in zip(dfs, labels):
            df = dfi.copy()
            if anomaly:
                df[category] = df[category] - min(df[category])
            plt.scatter(df['time'], df[category], label=label, s=5, alpha=0.3)
            meandt = df.groupby(by='time').mean()[category].reset_index()
            reg = LinearRegression().fit(meandt['time'].values.reshape(-1, 1), meandt[category])
            plt.plot(meandt['time'], meandt['time'] * reg.coef_ + reg.intercept_)
            print(f'{label} | coef: {reg.coef_}, intercept: {reg.intercept_}')
            pass
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.title(title)
        plt.legend()
        plt.tight_layout()
        if save:
            plt.savefig(save, dpi=self.dpi)
            pass
        else:
            plt.show()
            pass
        return
    # plot Multiple Mean Linear Regression with data stored with given keys.
    # if save directory is given, export plot as image with given dir. directory must include full path, with file extension.
    # category (optional): if given, plot data with given special category. default option is average, which indicates data of both eye's mean.
    # anomaly (optional): if given, plot anomaly of ys of data.
    def plotMultipleMeanRegression(self, keys, labels=[], save=None, title='title', xlabel='xlabel', ylabel='ylabel', category='average', anomaly=False):
        plt.clf()
        plt.figure(figsize=(self.figwidth, self.figheight))
        if not labels: labels = keys
        dfs = [self.dataframes[key] for key in keys]
        for dfi, label in zip(dfs, labels):
            df = dfi.copy()
            meandt = df.groupby(by='time').mean()[category].reset_index()
            if anomaly:
                meandt[category] = meandt[category] - min(meandt[category])
                pass
            plt.plot(meandt['time'], meandt[category], label=label)
            pass
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.title(title)
        plt.legend()
        plt.tight_layout()
        if save:
            plt.savefig(save, dpi=self.dpi)
            pass
        else:
            plt.show()
            pass
        return
    pass
