#적분 속도 법칙 그래프.py

import math
import matplotlib.pyplot as plt

x_set = []
nomal_y_set = []
ln_y_set = []
reverse_y_set = []

try:
    with open("DATA.csv", "r") as datafile:
        print("Data File Opened")
        while True:
            rowData = datafile.readline()
            print("Reading Data...")
            
            if not rowData: break
            
            x = float(rowData.split(',')[0])
            y = float(rowData.split(',')[1])
            
            x_set.append(x)
            nomal_y_set.append(y)
            ln_y_set.append(math.log(y))
            reverse_y_set.append(1/y)
            pass
        print("Data File Read Completed")
        pass
    print("Data File Closed")
    pass
except Exception as e:
    print("Error Occured: ", e)
    pass

plt.figure(1)
plt.plot(x_set, nomal_y_set, 'rs--')
plt.xlabel('Time')
plt.ylabel('Concentration')
plt.title('Time-Concentration Graph')
plt.savefig('Time-Concentration Graph.png', dpi=300)
print("Nomal Graph Generated")

plt.figure(2)
plt.plot(x_set, ln_y_set, 'rs--')
plt.xlabel('Time')
plt.ylabel('ln(Concentration)')
plt.title('Time-ln(Concentration) Graph')
plt.savefig('Time-ln(Concentration) Graph.png', dpi=300)
print("ln Graph Generated")

plt.figure(3)
plt.plot(x_set, reverse_y_set, 'rs--')
plt.xlabel('Time')
plt.ylabel('1/Concentration')
plt.title('Time-1/Concentration Graph')
plt.savefig('Time-reverse(Concentration) Graph.png', dpi=300)
print("Reverse Graph Generated")

try:
    with open("TABLE.csv", "w") as tablefile:
        print("Table File Opened")
        tablefile.write("Time,Concentration,ln(Concentration),1/Concentration\n")
        for i in range(0, len(x_set)):
            print("Writing Data...")
            tablefile.write(str(x_set[i])+","+ str(nomal_y_set[i])+","+str(ln_y_set[i])+","+str(reverse_y_set[i])+"\n")
            pass
        pass
    print("Table File Closed")
except Exception as e:
    print("Error Occured: ", e)
    pass

